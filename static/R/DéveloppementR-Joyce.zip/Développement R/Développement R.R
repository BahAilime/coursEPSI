# DEVELOPPEMENT R ---------------------------------------------------------

# Chargement des bibliothèques nécessaires

if(!require(devtools)){
  install.packages("devtools")
  library(devtools)
}


if(!require(dplyr)){
  install.packages("dplyr")
  library(dplyr)
}

if(!require(readr)){
  install.packages("readr")
  library(readr)
}


if(!require(xlsx)){
  install.packages("xlsx")
  library(xlsx)
}


if(!require(stringr)){
  install.packages("stringr")
  library(stringr)
}


if(!require(haven)){
  install.packages("haven")
  library(haven)
}


if(!require(nycflights13)){
  install.packages("nycflights13")
  library(nycflights13)
}


if(!require(knitr)){
  install.packages("knitr")
  library(knitr)
}


if(!require(tidyverse)){
  install.packages("tidyverse")
  library(tidyverse)
}


if(!require(lubridate)){
  install.packages("lubridate")
  library(lubridate)
}


if(!require(forstringr)){
  install.packages("forstringr")
  library(forstringr)
}




# Partie 1 : Introduction à R ---------------------------------------------

# 	Présentation de R et de son environnement
# 	Installation de R et R Studio
# 	Manipulation des objets de base : vecteurs, matrices et dataframes (sans packages)
## vecteurs :
x = c(1, 2, 3, 4, 5) # creation d'un vecteur
w = c("France", "Italie", "Senegal")

typeof(letters) # donne le type de vecteur
typeof(1:10)

x <- list("a", "b", 1:10) 
length(x) # donne la longueur d'un vecteur ou d'une liste


## vecteurs logiques
1:10 %% 3 == 0 # modulo, renvoie le reste de la division

## subsetting
x <- c("one", "two", "three", "four", "five") # sous sélection en fonction de la position
x[c(3, 2, 5)]


x[c(1, 1, 5, 5, 5, 2)] # sous sélection par la répétition

x[c(-1, -3, -5)] # les valeurs negatives retirent les élements en fonction de leurs positions


# Toutes les valeurs non manquantes
x <- c(10, 3, NA, 5, 8, 1, NA)
x[!is.na(x)]

# Si tu as nommé un vecteur, tu peux extraire son element en l'appellant
x <- c(abc = 1, def = 2, xyz = 5)
x[c("xyz", "def")]


## Matrice
matrix(1:6) # matrice de type vecteur colonne

matrix(1:6, ncol = 2) # creation d'une matrice avec 2 colonnes

matrix(1:6, nrow = 2) # creation d'une matrice avec 2 lignes

# Par défaut, le remplissage d’une matrice se fait par colonne
# Si vous voulez un remplissage par ligne, il faut utiliser l’argument byrow avec la valeur TRUE.
matrix(1:6, nrow = 1, byrow = TRUE)
matrix(1:6, nrow = 2, byrow = TRUE)

# dimension d'une matrice
xm <- matrix(1:6, nrow = 5, ncol = 10)
dim(xm)

# Avec les fonctions colnames() et rownames() on peut récupérer ou définir les noms des colonnes et des lignes .
colnames(xm) <- paste("X", 1:10, sep = "")
rownames(xm) <- paste("i", 1:5, sep = "")
xm

# Accéder aux éléments (lignes, colonnes) d’une matrice.
xm[1, ]  # ligne 1 (l'output est un vecteur)
xm[c(1, 3), ]  # ligne 1 et 3
xm[c("i1", "i3"), ]  # ligne "i1" et "i3"
xm[, 1:2]  # colonnes 1 et 2
xm[, c(TRUE, TRUE, rep(FALSE, 8))]  # idem
xm[, c("X1", "X2")]  # colonnes "X1" et "X2"
xm[, -c(1, 3)] # toutes les colonnes sauf 1 et 3
rbind(xm, 1:10) # ajoute une ligne à la matrice

# Operation matricielle : addition
X <- matrix(c(9, 2, -3, 2, 4, -2, -3, -2, 16), 3, byrow = TRUE)
Y <- matrix(0:8, ncol = 3)
X + Y

# Operation matricielle : soustraction
X - Y

# Operation matricielle : multiplication
X * Y


# Operation matricielle : division
X / Y

# Operation matricielle : déterminant
det(X)

# Operation matricielle : inverse
solve(X)

# Operation matricielle : moyenne par colonne
colMeans(X)



## Data frames

# Pour créer un data frame, créons des vecteurs qui vont le constituer
taille <- c(167, 192, 173, 174, 172, 167, 171, 185, 163, 170) # mesures en cm
poids <- c(86, 74, 83, 50, 78, 66, 66, 51, 50, 55) # mesures en Kg
prog <- c("Bac+2", "Bac", "Master", "Bac", "Bac", "DEA", "Doctorat", NA, "Certificat", "DES") # programme d'étude
sexe <- c("H", "H", "F", "H", "H", "H", "F", "H", "H", "H")

mydata <- data.frame(height = taille, weight = poids, prog, sexe, 11:20)
mydata


# struture du dataframe
length(mydata)
dim(mydata)
glimpse(mydata)


# parcourir son dataframe numero ou position
mydata[c(2, 3)]                    # colonnes 2 et 3
mydata[, c(2, 3)]                  # idem
mydata |> subset(select = c(2, 3)) # idem

# parcourir son dataframe par nom
mydata$weight                       # colonne "weight" (resultat = vecteur)
mydata["weight"]                    # colonne "weight" (resultat = data.frame)
mydata |> subset(select = "weight") # idem
mydata |> subset(select = weight)   # idem


# parcourir son dataframe par condition logique
mydata[mydata$sexe == "H", ]           # sélectionner uniquement les hommes
mydata |> subset(subset = sexe == "H") # idem
mydata |> subset(sexe == "H")          # idem






# Partie 2 : Gestion des données avec R -----------------------------------

# Importation et exportation des données

## donnees R
data <- iris

## donnees csv
territory <- read.csv("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/territory.csv", header = TRUE, sep = ";")

## donnees xlsx
reseller <- xlsx::read.xlsx("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/reseller.xlsx", sheetIndex = 1, header = TRUE)

## donnees web
url_csv <- "https://s3.amazonaws.com/assets.datacamp.com/course/importing_data_into_r/swimming_pools.csv"
data_from_web <- read.csv(url_csv)

## donnnes GIT
url_csv <- "https://raw.githubusercontent.com/lrjoshi/webpage/master/public/post/c159s.csv"
data_from_git <- read.csv(url_csv)


## donnees SAS
data_from_sas <- haven::read_sas("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/eventrepository.sas7bdat")


## donnees SPSS
data_from_spss <- haven::read_sav("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/health_control.sav")


# data from xml
require(xml2)
path_xml <- "C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/Books.xml"
data_xml <- xml2::read_xml(path_xml)

xml2::xml_structure(data_xml)

id = xml_find_all(data_xml, "//book")
author = xml_text(xml_find_all(id, "//author"))
title = xml_text(xml_find_all(id, "//title"))
category = xml_text(xml_find_all(id, "//genre"))
price = xml_text(xml_find_all(id, "//price"))

df <- data.frame(NAME = author, 
                 TITLE = title,
                 GENRE = category,
                 PRICE = price) 

View(df)


# Manipulation des données avec dplyr
## Chargement des trois tables du jeu de données
data(flights)
data(airports)
data(airlines)

## Slice
slice(airports, 345) # slice(airports, 345)
slice(airports, 1:5) # les 5 premières lignes

## Filter
filter(flights, month == 1)
filter(flights, dep_delay >= 10 & dep_delay <= 15)
filter(flights, distance == max(distance))

## select, renamen relocate
select(airports, lat, lon)
select(airports, -lat, -lon)
select(flights, starts_with("dep_"))


select(flights, all_of(c("year", "month", "day")))# all_of retourne une liste de colonnes définies
select(flights, all_of(c("century", "year", "month", "day"))) # all_of renverra une erreur si une variable n’est pas trouvée
select(flights, any_of(c("century", "year", "month", "day"))) # any_of ne renvoie pas d'erreur si une variable n’est pas trouvée
select(flights, where(is.character)) # where permet de selectionner des variables textuelles (logique)
select(airports, name, everything())
relocate(airports, lon, lat, name)
dplyr::rename(airports, longitude = lon, latitude = lat)
dplyr::arrange(flights, dep_delay) # arrange tri les lignes d'un tableau (croissant)
dplyr::arrange(flights, month, dep_delay) # tri selon le mois et le retard au départ
dplyr::arrange(flights, desc(dep_delay)) # tri décroissant

tmp <- dplyr::arrange(flights, desc(dep_delay)) %>%
  slice(1:3)

# mutate
airports <- mutate(airports, alt_m = alt / 3.2808)
select(airports, name, alt, alt_m)


flights <- mutate(flights, 
                  distance_km = distance / 0.62137,
                  vitesse = distance_km / air_time * 60)
select(flights, distance, distance_km, vitesse)


flights <- mutate(flights,
                  type_retard = case_when(
                    dep_delay > 0 & arr_delay > 0 ~ "Retard départ et arrivée",
                    dep_delay > 0 & arr_delay <= 0 ~ "Retard départ",
                    dep_delay <= 0 & arr_delay > 0 ~ "Retard arrivée",
                    TRUE ~ "Aucun retard"))


# recode
flights$month_name <- recode_factor(flights$month,
                                    "1" = "Jan",
                                    "2" = "Feb",
                                    "3" = "Mar",
                                    "4" = "Apr",
                                    "5" = "May",
                                    "6" = "Jun",
                                    "7" = "Jul",
                                    "8" = "Aug",
                                    "9" = "Sep",
                                    "10" = "Oct",
                                    "11" = "Nov",
                                    "12" = "Dec"
)


# operations groupées
flights %>% group_by(month)


flights %>% group_by(month) %>% slice(1)


flights %>% 
  group_by(month) %>% 
  mutate(mean_delay_month = mean(dep_delay, na.rm = TRUE)) %>% 
  select(dep_delay, month, mean_delay_month)



flights %>% 
  group_by(month) %>% 
  dplyr::arrange(desc(dep_delay))



# summirize
flights %>% 
  dplyr::summarise(
    retard_dep = mean(dep_delay, na.rm=TRUE),
    retard_arr = mean(arr_delay, na.rm=TRUE)
  )



flights %>%
  group_by(month) %>%
  dplyr::summarise(
    max_delay = max(dep_delay, na.rm=TRUE),
    min_delay = min(dep_delay, na.rm=TRUE),
    mean_delay = mean(dep_delay, na.rm=TRUE)
  )


flights %>%
  group_by(dest) %>%
  dplyr::summarise(nb = n())



flights %>%
  group_by(month, dest) %>%
  dplyr::summarise(nb = n()) %>%
  dplyr::arrange(desc(nb))



# Introduction aux techniques de nettoyage des données : identification des données manquantes
# tester s'il y a une valeur manquante
y <- c(1,2,3,NA)
is.na(y) # returns a vector (F F F T)

# localiser la valeur manquante
which(is.na(y))

# compter les valeurs manquantes
sum(is.na(y))

# compter les valeurs manquantes sur plusieurs colonnes
colSums(is.na(iris))

## Exercice :
# 1. Combien il y a de valeurs manquantes dans le jeu de données fligths ?
sum(is.na(flights))
# 2. Sur quelles colonnes trouvent t-on des valeurs manquantes ?
colSums(is.na(flights))
# 3. Imputez les valeurs manquantes par la moyenne ou mode, colonne par colonne
glimpse(flights)

flights_imputed <- flights %>%
  mutate(dep_time = mean(na.omit(dep_time)),
         dep_delay = mean(na.omit(dep_delay)),
         arr_time = mean(na.omit(arr_time)),
         arr_delay = mean(na.omit(arr_delay)),
         tailnum = mode(na.omit(tailnum)),
         air_time = mean(na.omit(air_time)))

sum(is.na(flights_imputed))



# Introduction aux techniques de nettoyage des données : gestion des valeurs aberrantes et exrêmes
ggplot(mpg, aes( x=class,y=hwy, fill=class)) +
  geom_boxplot()+ 
  xlab(label = "Type of car") +
  ylab(label = "Highway miles per gallon") +
  theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1))+
  theme(legend.position="none")+
  ggtitle("Exemple de boxplots sur les données mpg") 

# les outliers sont représentés sous forme de points.

## récupération des outliers
# sélection des données suv
suv <- mpg %>%
  filter(class=="suv") # liste des outliers des SUV

outlier_val <- boxplot.stats(suv$hwy)$out
outlier_val

## récupérer l'indice des outliers
outlier_idx <- which(suv$hwy %in% c(outlier_val))
outlier_idx

suv[outlier_idx,] # verifions les lignes concernées


# remplacemement des valeurs extremes par la moyenne du groupe
suv[outlier_idx, "hwy"] <- as.integer(mean(suv$hwy))
print(suv[outlier_idx, "hwy"])




 
# Introduction aux techniques de nettoyage des données : détection et gestion des doublons
# trouver les doublons
x <- c(1, 1, 4, 5, 4, 6)
duplicated(x)
 
# extraire les doublons
x[duplicated(x)] 

# retirer les doublons
x[!duplicated(x)]

# retirer les doublons d'un datagrame
df <- iris %>%
  distinct() # ou unique()

# retirer les doublons à partir de deux colonnes : Sepal.Length and Petal.Width
df %>% distinct(Sepal.Length, Petal.Width, .keep_all = TRUE)



# Introduction aux techniques de nettoyage des données: conversion des types de données
# Conversion de character à numeric
char_vector <- c("1", "2", "3")
numeric_vector <- as.numeric(char_vector)

# Conversion de numeric à character
numeric_vector <- c(1, 2, 3)
char_vector <- as.character(numeric_vector)


# Conversion de factor à character
factor_vector <- factor(c("A", "B", "C"))
char_vector <- as.character(factor_vector)

# Conversion de factor à numeric
numeric_vector <- as.numeric(factor_vector)


# Conversion de character à date
char_date <- "2022-01-01"
date <- as.Date(char_date)

# Conversion de factor à date
factor_date <- factor("2022-01-01")
date <- as.Date(as.character(factor_date))


# Conversion de date à character
date <- as.Date("2022-01-01")
char_date <- as.character(date)

# Conversuion de logical à numeric
logical_vector <- c(TRUE, FALSE)
numeric_vector <- as.numeric(logical_vector)

# Conversion de logical à character
char_vector <- as.character(logical_vector)



# Introduction aux techniques de nettoyage des données : correction des erreurs de saisies
# détecter les motifs
data_from_git <- data_from_git %>%
  mutate(Experiment = if_else(str_detect(Experiment, "EXP")==TRUE, "Experiment", ""))

# remplacer des motifs
data_from_git <- data_from_git %>%
  mutate(Virus = str_replace(Virus, "C", "Corona"))



# Introduction aux techniques de nettoyage des données : normalisation et standardisation
# normalisation
df = c(1200,34567,3456,12,3456,0985,1211) %>%
  as.data.frame()

summary(data)
library(caret)
process <- preProcess(df, method=c("range"))

norm_scale <- predict(process, as.data.frame(df))
norm_scale

# standardisation
scale_df <- as.data.frame(scale(df))
scale_df


# Introduction aux techniques de nettoyage des données : validation des formats de date et heure
today()
now()
ymd("2017-01-31")
ymd_hms("2017-01-31 20:11:59")
mdy_hm("01/31/2017 08:01")


# créer une date ou une date-heure à partir de colonnes séparées,
flights |> 
  select(year, month, day, hour, minute) |> 
  mutate(
    departure = make_datetime(year, month, day, hour, minute),
    departure_date = make_date(year, month, day)  ) |> 
  head()

# durées
diff <- ymd("2021-06-30") - ymd("1979-10-14")
diff





# Partie 3 : Visualisation des données avec R -----------------------------

#  	Utilisation des bibliothèques ggplot2 et plotly pour créer des graphiques
#  	Personnalisation des graphiques : axes, légendes, couleurs, etc.
#  	Création de graphiques interactifs avec plotly

## GGPLOT2 : scatterplot (nuage de points)
library(tidyverse)
library(ggpubr) 

theme_set(
  theme_bw() + 
    theme(legend.position = "top")
)

p <- ggplot(mtcars, aes(mpg, wt)) +
  geom_point() +
  geom_smooth(method = lm) +
  stat_cor(method = "pearson", label.x = 20)
p



## GGPLOT2 : scatterplot (nuage de points) avec zoom contextuel
library(ggforce)

ggplot(iris, aes(Petal.Length, Petal.Width, colour = Species)) +
  geom_point() +
  facet_zoom(x = Species == "versicolor")


## GGPLOT2 : scatterplot (nuage de points) avec encerclement de points
library("ggalt")

circle.df <- iris %>% filter(Species == "setosa")

ggplot(iris, aes(Petal.Length, Petal.Width)) +
  geom_point(aes(colour = Species)) + 
  geom_encircle(data = circle.df, linetype = 2)


## GGPLOT2 : scatterplot (nuage de points) avec bulles
ggplot(mtcars, aes(mpg, wt)) +
  geom_point(aes(size = qsec), alpha = 0.5) +
  scale_size(range = c(0.5, 12))  # Adjust the range of points size


## GGPLOT2 : scatterplot (nuage de points) avec densité

ggscatterhist(
  iris, x = "Sepal.Length", y = "Sepal.Width",
  color = "Species", size = 3, alpha = 0.6,
  palette = c("#00AFBB", "#E7B800", "#FC4E07"),
  margin.params = list(fill = "Species", color = "black", size = 0.2)
)



## GGPLOT2 : densité de distributions
ggplot(iris, aes(Sepal.Length, color = Species)) +
  geom_density() +
  scale_color_viridis_d()


## GGPLOT2 : densité de distributions avec moyennes sur chaque groupe
mu <- iris %>%
  group_by(Species) %>%
  summarise(grp.mean = mean(Sepal.Length))

ggplot(iris, aes(Sepal.Length, color = Species)) +
  geom_density() +
  geom_vline(aes(xintercept = grp.mean, color = Species),
             data = mu, linetype = 2) +
  scale_color_viridis_d()


## GGPLOT2 : Histogrammes
# Basic histogram with mean line
ggplot(iris, aes(Sepal.Length)) +
  geom_histogram(bins = 20, fill = "white", color = "black")  +
  geom_vline(aes(xintercept = mean(Sepal.Length)), linetype = 2)

# Add density curves
ggplot(iris, aes(Sepal.Length, stat(density))) +
  geom_histogram(bins = 20, fill = "white", color = "black")  +
  geom_density() +
  geom_vline(aes(xintercept = mean(Sepal.Length)), linetype = 2)



## GGPLOT2 : Histogrammes, couleur par groupe
ggplot(iris, aes(Sepal.Length)) +
  geom_histogram(aes(fill = Species, color = Species), bins = 20, 
                 position = "identity", alpha = 0.5) +
  scale_fill_viridis_d() +
  scale_color_viridis_d()


## GGPLOT2 : barplot basique
df <- mtcars %>%
  rownames_to_column() %>%
  as.data.frame() %>%
  mutate(cyl = as.factor(cyl)) %>%
  select(rowname, wt, mpg, cyl)
df

ggplot(df, aes(x = rowname, y = mpg)) +
  geom_col() +
  rotate_x_text(angle = 45)





## GGPLOT2 : barplot avec ajout de couleurs
ggplot(df, aes(x = rowname, y = mpg)) +
  geom_col() +
  geom_col( aes(fill = cyl)) +
  rotate_x_text(angle = 45)



## GGPLOT2 : séries longues
df <- economics %>%
  select(date, psavert, uempmed) %>%
  gather(key = "variable", value = "value", -date)
head(df, 3)

ggplot(df, aes(x = date, y = value)) + 
  geom_line(aes(color = variable), size = 1) +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) +
  theme_minimal()





## PLOTLY
# 2D Scatterplot
library(plotly)

data(mtcars)

cars <- mtcars

p <- plot_ly(cars, x=cars$wt, y=cars$mpg, 
             mode="markers", color=cars$hp, size=cars$qsec) %>%
  layout(xaxis = list(title = "Weight (1000 lbs)"),
         yaxis = list(title = "miles per gallon") )

p


# 3D Scatterplot
p <- plot_ly(cars, x=cars$wt, y=cars$mpg, z=cars$hp, 
             type="scatter3d", mode="markers", 
             color=cars$drat, size=cars$qsec) %>%
  layout(scene=list(
    xaxis = list(title = "Weight (1000 lbs)"),
    yaxis = list(title = "miles per gallon"),
    zaxis = list(title = "Gross horsepower)"))
  )

p



# séries longues
graph <- economics %>% 
  plot_ly(x=~date) %>% 
  add_trace(y=~unemploy/400, type="scatter", mode="lines")

graph


# Boites à moustaches
boxplot <- mtcars %>% 
  plot_ly(x=~factor(cyl), y=~mpg) %>% 
  add_trace(type="scatter", name="scatter") %>% 
  add_boxplot(name="Boxplot") %>% 
  layout(
    title="Fuel Efficiency"
  )

boxplot




# Partie 4 : Analyse de données avec R ------------------------------------

# Introduction aux statistiques descriptives
# Statistiques univariées

# Calcul de la moyenne
mean(mtcars$hp)

# Calcul de la médiane
median(mtcars$hp)

# Calcul de la variance
var(mtcars$hp)

# Calcul de l'écart-type : standard deviation
sd(mtcars$hp)

# Résumé statistique
summary(mtcars$hp)

# Calcul des quantiles
quantile(mtcars$hp)

# Utilisation du package psych pour des statistiques plus avancées
library(psych)

# Résumé complet des statistiques descriptives
describe(mtcars$hp)
describe(mtcars)

# Calcul de l'asymétrie : SKEWNESS
    # L'asymétrie mesure la symétrie de la distribution des données par rapport à 
    # la moyenne. Une valeur positive indique une queue de distribution plus longue 
    # du côté droit de la moyenne, tandis qu'une valeur négative indique une queue plus 
    # longue du côté gauche.
skew(mtcars$hp)

p <- ggplot(mtcars, aes(x=hp)) + 
  geom_density()
p

# Calcul du coefficient d'aplatissement
    # Le coefficient d'aplatissement mesure la forme de la distribution des données 
    # par rapport à la distribution normale. Une valeur positive indique une 
    # distribution plus pointue que la distribution normale, tandis qu'une valeur 
    # négative indique une distribution moins pointue 
kurtosi(mtcars$hp)
  
p <- ggplot(mtcars, aes(x=hp)) + 
    geom_density()
p


# Utilisation des tests statistiques : DEFINITION
    # Un test statistique permet de prendre une décision entre deux hypothèses.
    # Il est utilisé pour déterminer si une différence ou une relation observée entre les données 
    # est statistiquement significative, c'est-à-dire si elle est probablement due à une vraie différence 
    # ou relation dans la population étudiée, plutôt que simplement due au hasard.
          
        # 1ere étape : Définir l’hypothèse nulle (H0) et l’hypothèse alternative (H1).
        # H0 représente généralement l'idée qu'il n'y a pas de différence 
        # ou de relation entre les groupes comparés, tandis que H1 suggère qu'il y en a une.
        
        # 2eme étape : L’erreur de première et deuxième espèce
        # L'erreur suggère que il y a toujours un risque de se tromper. 
        # L’erreur de première espèce alpha correspond au risque de rejeter l’hypothèse nulle H0 alors qu’elle est vraie : c’est un « faux positif ».
        # L’erreur de seconde espèce beta correspond au risque d’accepter l’hypothèse nulle H0 alors qu’elle est fausse : c’est un « faux négatif ».
        # Par défaut, on fixe le paramètre alpha à 5% : c’est-à-dire que la probabilité maximale de rejeter HO si elle est vraie est de 5%. 
        
        # 3eme étape : choisir le test approprié
        
        # 4eme étape : analyse des résultats
        # La p-value est le niveau à partir duquel on se met à rejeter H0. C’est ce qui va nous permettre de répondre au test.
            # Si p-value < alpha, alors on rejette H0 au niveau alpha,  
            # Si p-value > alpha, alors on conserve H0 au niveau alpha. 






# Utilisation des tests statistiques pour comparer des groupes : Test t de Student
  # Le test de student (ou t-test) est utilisé pour comparer deux moyennes.
  # Comparons les poids de poulpes mâles et femelles à l'âge adulte.
  # Nous disposons des données de 15 poulpes mâles et 13 femelles.
  # Nous souhaitons tester l'égalité des moyennes des poids des poules femmelles (mu 1) et mâles (mu2),
  # avec une erreur de premiere espece de 5%.
  

  # 1. chargement des données
poulpes <- read.csv("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/poulpe.csv", 
                      header = TRUE, sep = ";", fileEncoding = "windows-1252")
  
  # 2. Formulation des hypotheses
    # H0 : les moyennes des poids sont egales entre les sexes (mu1 = mu2)
    # H1 : les moyennes des poids sont differentes (mu1 != mu2)
     
  # 3. comparaison graphique : distribution des poids
ggplot(poulpes, aes(x = Sexe, y = Poids, fill = Sexe)) +
  geom_boxplot()+ 
  xlab(label = "Sexe") +
  ylab(label = "Poids") +
  theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1))+
  theme(legend.position="none")+
  ggtitle("Distribution des poids") 
 
# les mâles sont généralement plus lourd que les femelles (médianes et quartiles de poids)  

# 4. réalisation du test
t.test(Poids ~ Sexe, 
       alternative = "two.sided", # bi-latérial car H1 : les moyennes des poids sont differentes. Si H1 était les moyennes des poids sont faibles, alors on aurait mis "unilateral" 
       conf.level = .95,
       data = poulpes)

# conclusion : la p-value vaut 0.001 < 5%. Donc on rejete H0, les moyennes sont significativement différentes.
# La moyenne des mâles dans l'échantillon estimée à 2700 grammes est donc significativement différente de celle des femelles estimée à 1405 grammes.






# Utilisation des tests statistiques pour comparer des groupes : ANOVA
    # L'ANOVA est l'analyse de la variance.
    # C'est une extension du test de student.
    # L'ANOVA permet de voir si une variable numérique (Poids) a des valeurs différentes en fonction de plusieurs groupes (Sexe)
    
    # 1. Formulation des hypotheses
      # H0 : le sexe n'influence pas le poids des poules (qui des males et des femelles sont les plus lourds ?)
      # H1 : le sexe a une influence sur le poids des poulpes 

anova <- aov(Poids ~ factor(Sexe),
             data = poulpes)

summary(anova)

# Conclusion : le facteur sexe est significatif avec une valeur p < 5%. On rejette donc H0. Le sexe influence donc le poids des poulpes.







# Utilisation des tests statistiques pour comparer des groupes : Test de Wilcoxon-Mann-Whitney
    # Le test de Wilcoxon (test du rang de signe de Wilcoxon) vérifie si les valeurs moyennes de 
    # deux groupes dépendants diffèrent significativement l'une de l'autre.

    # Exemple en médecine : nous allons vérifier si les performances de la mémoire sont meilleures le matin ou le soir.
    # Hypothèse nulle : il n'y a pas de différence entre le matin et le soir
    # Hypothèse alternative : il existe une différence (par rapport à la tendance centrale) entre le matin et le soir
    
temps_reaction_matin <- c(34, 36, 41, 39, 44, 37)
flag1 <- rep("matin", length(temps_reaction_matin))

temps_reaction_soir <- c(45, 33, 35, 43, 42, 42)
flag2 <- rep("soir", length(temps_reaction_soir))

df1 <- data.frame(reaction = temps_reaction_matin, moment = flag1)
df2 <- data.frame(reaction = temps_reaction_soir, moment = flag2)

df <- df1 %>%
  bind_rows(df2)

View(df)


ggplot(df, aes(x = reaction, y = moment, fill = moment)) +
  geom_boxplot() +
  geom_point() +
  xlab(label = "reaction") +
  ylab(label = "moment") +
  theme(axis.text.x = element_text(angle=30, hjust=1, vjust=1))+
  theme(legend.position="none")+
  ggtitle("Distribution des reactions") 


# test statistique
wilcox.test(reaction ~ moment,
            alternative = "two.sided",
            conf.int = TRUE,
            data = df)

# taille de l'effet
df %>%
  wilcox_effsize(reaction ~ moment)

# critère de taille de l'effet : l'effet varie entre -1 et 1
    # si taille effet < 0.1, alors aucun effet sinon très faible
    # si taille effet = 0.1, alors effet faible
    # si taille effet = 0.3, alors effet moyen
    # si taille effet = 0.5, alors effet important


# Conclusion : on retient H0 car p-value > 5% et une taille d'effet "petite" est détectée.
# Pas étonnant, les moyennes sont proches
df %>% group_by(moment) %>% summarise(avg = mean(reaction),
                                      sd = sd(reaction))


# Utilisation des tests statistiques pour comparer des groupes : Test de Kruskal-Wallis
# Utilisation des tests statistiques pour comparer des groupes : Test de signe (Wilcoxon)
# Utilisation des tests statistiques pour comparer des groupes : Test de Friedman

# Utilisation des tests statistiques pour comparer des groupes : Test de chi-carré (test d'indépendance)
  # le test du khi-deux implique de vérifier si les fréquences observées dans une ou plusieurs catégories correspondent aux fréquences attendues.
  # Ici, on étudie la couleur des cheveux des garçons et des filles.
  # Nous voulons savoir si la couleur des cheveux est indépendante du sexe, avec une erreur de 5%
  
  # HO : la couleur des cheveux est indépendante du sexe
  # H1 : la couleur des cheveux dépend du sexe


df <- data.frame("Blond" = c(592, 544),
                 "Roux" = c(119, 97),
                 "Châtain" = c(849, 677),
                 "Brun" = c(504, 451),
                 "Noir_de_jais" = c(36, 14),
                 row.names = c("Garçons", "Filles"))

chisq.test(df)

    # Conclusion : On accepte H0. La couleur des cheveux est indépendante du sexe.



# Utilisation des tests statistiques pour comparer des groupes : Régression linéaire avec interaction
# Utilisation des tests statistiques pour comparer des groupes : Test de Levene ou Barlett

# Régression linéaire multiple
# 1. chargement des données
ozone <- read.delim("C:/Users/joyce.mbiguidi/Documents/EPSI_Nantes - Orlane CALLAUD/Cours/Développement R/ozone.txt", 
                    header = TRUE, sep = " ", fileEncoding = "windows-1252")
View(ozone)

ozone <- ozone %>%
  select(-c(vent, pluie, maxO3v))

lin_reg1 <- lm(maxO3 ~ ., data = ozone)
summary(lin_reg1)

# stepwise model
lin_reg2 <- step(lin_reg1, direction = "backward", )
summary(lin_reg2)



# Introduction à l'analyse de données multidimensionnelles avec FactoMineR




# Partie 5 : Programmation avancée avec R ---------------------------------

# Structures de contrôle : boucles, conditions, fonctions
# afficher les nombres de 1 à 10
for (i in 1:10) {
print(i)
}

# boucle for pour calculer la somme des carrés des nombres de 1 à 5.
somme_carres <- 0
for (i in 1:5) {
  somme_carres <- somme_carres + i^2
}
print(somme_carres)



# une boucle for pour trouver la moyenne d'une liste de nombres.
nombres <- c(5, 10, 15, 20, 25)
somme <- 0
for (nombre in nombres) {
  somme <- somme + nombre
}
moyenne <- somme / length(nombres)
print(moyenne)



# une boucle for pour créer un vecteur de carrés des nombres de 1 à 10.

carres <- c()
for (i in 1:10) {
  carres <- c(carres, i^2)
}
print(carres)


# une boucle while pour afficher les carrés des nombres de 1 à 5.
i <- 1
while (i <= 5) {
  print(i^2)
  i <- i + 1
}


# une structure if pour déterminer si un nombre est pair ou impair.
nombre <- 10

if (nombre %% 2 == 0) {
  print("Le nombre est pair.")
} else {
  print("Le nombre est impair.")
}


# une structure if-else pour déterminer la catégorie d'âge en fonction de l'âge fourni.
age <- 25

if (age < 18) {
  cat("Mineur")
} else if (age >= 18 && age < 65) {
  cat("Adulte")
} else {
  cat("Senior")
}


# une fonction pour calculer la somme de deux nombres.
addition <- function(a, b) {
  return(a + b)
}

resultat <- addition(3, 5)
print(resultat)


# une fonction pour calculer la moyenne d'une liste de nombres.
moyenne <- function(nombres) {
  return(mean(nombres))
}

liste_nombres <- c(10, 20, 30, 40, 50)
resultat <- moyenne(liste_nombres)
print(resultat)


# une fonction pour déterminer si un nombre est pair ou impair.
parite <- function(nombre) {
  if (nombre %% 2 == 0) {
    return("Pair")
  } else {
    return("Impair")
  }
}

resultat <- parite(7)
print(resultat)


# une fonction pour calculer la factorielle d'un nombre.
factorielle <- function(n) {
  if (n == 0) {
    return(1)
  } else {
    return(n * factorielle(n - 1))
  }
}

resultat <- factorielle(5)
print(resultat)



# une fonction pour inverser une chaîne de caractères.
inverser_chaine <- function(chaine) {
  return(paste0(rev(strsplit(chaine, "")[[1]]), collapse = ""))
}

resultat <- inverser_chaine("hello")
print(resultat)



# exercice : creez deux fonctions. L'une aura pour but de normaliser et l'autre de standardiser les données
# Min-max normalization
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

df_normalized <- as.data.frame(lapply(df, normalize))

# Standardization
standardize <- function(x) {
  return((x - mean(x)) / sd(x))
}

df_standardized <- as.data.frame(lapply(df, standardize))


# Programmation fonctionnelle avec purrr
# map() pour appliquer une fonction à chaque élément d'un vecteur.
library(purrr)

# Créer un vecteur
vecteur <- c(1, 2, 3, 4, 5)

# Ajouter 1 à chaque élément du vecteur
resultat <- map(vecteur, ~ .x + 1)
print(resultat)


# map_dbl() pour appliquer une fonction à chaque élément d'un vecteur et obtenir un vecteur numérique en sortie.
library(purrr)

# Créer un vecteur
vecteur <- c(1, 2, 3, 4, 5)

# Calculer le carré de chaque élément du vecteur
resultat <- map_dbl(vecteur, ~ .x^2)
print(resultat)


# map_df() pour appliquer une fonction à chaque élément d'une liste et obtenir un dataframe en sortie.
library(purrr)
library(dplyr)

# Créer une liste de vecteurs
liste <- list(vecteur1 = c(1, 2, 3), vecteur2 = c(4, 5, 6))

# Calculer la moyenne de chaque vecteur et créer un dataframe
resultat <- map_df(liste, ~ tibble(moyenne = mean(.x)))
print(resultat)


# reduce() pour réduire une liste en un seul résultat en appliquant une fonction d'accumulation.
# Créer une liste de nombres
liste <- list(1, 2, 3, 4, 5)

# Calculer la somme des nombres dans la liste
resultat <- reduce(liste, `+`)
print(resultat)


# pmap() pour appliquer une fonction à plusieurs arguments sur chaque élément d'une liste.
# Créer une liste de vecteurs
liste <- list(c(1, 2, 3), c(4, 5, 6), c(7, 8, 9))

# Ajouter les éléments correspondants des vecteurs
resultat <- pmap(liste, ~ sum(c(...)))
print(resultat)




# Création de packages R
## Exercice :
## Créez un package R appelé monpackage contenant une fonction nommée carre() qui prend un nombre comme argument et renvoie son carré.

# Solution :
  #1. Créez un nouveau répertoire nommé monpackage.
  #2. À l'intérieur de ce répertoire, créez un fichier R nommé carre.R dans le répertoire R/. Écrivez la fonction carre() dans ce fichier :
#' Calcule le carré d'un nombre
#' 
#' @param x Le nombre à mettre au carré
#' @return Le carré du nombre
#' @examples
#' carre(3)
#' @export
carre <- function(x) {
  return(x^2)
}

  #3. Dans le même répertoire, créez un fichier DESCRIPTION avec les métadonnées de votre package :
#' Package: monpackage
#' Type: Package
#' Title: Une démo de package R
#' Version: 0.1.0
#' Author: Votre nom
#' Maintainer: Votre nom <votre@email.com>
#' Description: Un package R simple pour calculer le carré d'un nombre.
#' License: MIT + file LICENSE
#' Encoding: UTF-8
#' LazyData: true

  #4. Créez un fichier NAMESPACE avec la directive d'exportation pour rendre la fonction carre() accessible :
export(carre)


  # 5. Enfin, exécutez roxygen2::roxygenize() pour générer la documentation à partir des commentaires roxygen2.
  # 6. Vous pouvez maintenant construire et installer votre package avec devtools :
devtools::build()
devtools::install()

  # 7. Une fois cela fait, vous pouvez utiliser votre package en l'important avec library(monpackage) et en appelant la fonction carre()
library(monpackage)
carre(3)





# Bonnes pratiques de programmation avec R





















