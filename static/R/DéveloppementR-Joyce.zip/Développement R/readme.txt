############## Développement R (14h) ##############

PARTIE 1 - INTRODUCTION A R (2H)
Section 1 : Introduction à R
	- Présentation de R et de son environnement
	- Installation de R et R Studio
	- Manipulation des objets de base : vecteurs, matrices et dataframes (sans packages)

	Exercice 1 à 3 : cf. syllabus


PARTIE 2 - Gestion des données avec R (4h)
Section 1 - Gestion des données avec R
	- Importation et exportation des données
	- Manipulation des données avec dplyr
	- Introduction aux techniques de nettoyage des données
		1. Identification des données manquantes :
		Technique : Utilisation de fonctions comme is.na() pour identifier les valeurs manquantes.
		Actions : Imputation de valeurs manquantes ou suppression des lignes/colonnes avec des données manquantes.
		
		2. Gestion des valeurs aberrantes (outliers) :
		Technique : Utilisation de statistiques descriptives, graphiques boxplot, ou tests statistiques.
		Actions : Transformation des valeurs aberrantes, suppression ou traitement spécifique selon le contexte.

		3. Gestion des valeurs extrêmes :
		Technique : Utilisation de méthodes statistiques ou graphiques pour identifier les valeurs extrêmes.
		Actions : Traitement approprié, par exemple, transformation logarithmique.

		4. Détection et gestion des doublons :
		Technique : Utilisation de fonctions comme duplicated() pour identifier les duplicatas.
		Actions : Suppression des duplicatas ou agrégation des données dupliquées.

		5. Conversion des types de données :
		Technique : Utilisation de fonctions comme as.numeric(), as.character(), etc.
		Actions : Assurer que les types de données sont appropriés pour l'analyse.
		
		6. Correction des erreurs de saisie :
		Technique : Vérification des plages valides, utilisation de méthodes de correspondance (matching) pour identifier des erreurs potentielles.
		Actions : Correction des erreurs manuellement ou à l'aide d'algorithmes.
		
		7. Gestion des valeurs incohérentes :
		Technique : Utilisation de règles métier pour détecter des incohérences.
		Actions : Correction manuelle, imputation, ou suppression des données incohérentes.
		
		8. Normalisation et standardisation :
		Technique : Mise à l'échelle des variables pour les rendre comparables.
		Actions : Utilisation de techniques comme la normalisation Min-Max ou la standardisation Z.

		9. Validation des formats de date et heure :
		Technique : Vérification des formats, conversion des types si nécessaire.
		Actions : Imputation, suppression ou correction des valeurs non conformes.

		10. Documentation du processus de nettoyage :
		Technique : Tenir un journal des modifications apportées aux données.
		Actions : Facilite la reproductibilité et la transparence du processus.

	Exercices 1 à 3 : cf. syllabus


PARTIE 3 - VISUALISATION DES DONNEES AVEC R (4h)
Section 1 : Visualisation des données avec R
	- Utilisation des bibliothèques ggplot2 et plotly pour créer des graphiques
	- Personnalisation des graphiques : axes, légendes, couleurs, etc.
	- Création de graphiques interactifs avec plotly

	Exercices 1 à 3 : cf. syllabus


PARTIE 4 - ANALYSE DE DONNEES AVEC R
Section 1 : Analyse de données avec R
	- Introduction aux statistiques descriptives avec R
	- Utilisation des tests statistiques pour comparer des groupes
		1. Test t de Student :
		Type de données : Variables continues, deux groupes indépendants.
		Exemple d'utilisation : Comparaison des moyennes de deux groupes (e.g., groupe de traitement vs groupe de contrôle).
		Fonction R : t.test().

		2. ANOVA (Analyse de la variance) :
		Type de données : Variables continues, plus de deux groupes indépendants.
		Exemple d'utilisation : Comparaison des moyennes de plusieurs groupes.
		Fonction R : aov().

		3. Test de Wilcoxon-Mann-Whitney (test U de Mann-Whitney) :
		Type de données : Variables ordinales ou continues, deux groupes indépendants, non paramétrique.
		Exemple d'utilisation : Comparaison des distributions de deux groupes indépendants.
		Fonction R : wilcox.test().
		
		4. Test de Kruskal-Wallis :
		Type de données : Variables ordinales ou continues, plus de deux groupes indépendants, non paramétrique.
		Exemple d'utilisation : Comparaison des distributions de plusieurs groupes.
		Fonction R : kruskal.test().

		5. Test de signe (Wilcoxon) :
		Type de données : Variables continues, deux groupes appariés, non paramétrique.
		Exemple d'utilisation : Comparaison des médianes de deux groupes appariés.
		Fonction R : wilcox.test() avec l'argument paired = TRUE.

		6. Test de Friedman :
		Type de données : Variables ordinales ou continues, plus de deux groupes appariés, non paramétrique.
		Exemple d'utilisation : Comparaison des distributions de plusieurs groupes appariés.
		Fonction R : friedman.test().

		7. Test de chi-carré :
		Type de données : Variables catégorielles, indépendantes.
		Exemple d'utilisation : Comparaison des fréquences observées avec les fréquences attendues.
		Fonction R : chisq.test().

		8. Régression linéaire (pour comparer les pentes) :
		Type de données : Variables continues, deux groupes ou plus, interaction entre les groupes et la variable indépendante continue.
		Exemple d'utilisation : Comparaison des pentes de régression entre les groupes.
		Fonction R : lm() avec interaction.
		
		9. Test de Levene ou Bartlett :
		Type de données : Variables continues, comparaison de la variance entre deux ou plusieurs groupes.
		Exemple d'utilisation : Vérification de l'égalité des variances avant un test t ou une ANOVA.
		Fonction R : levene.test() ou bartlett.test().

	- Réalisation de modèles de régression : multiple et simple
	- Introduction à l'analyse de données multidimensionnelles avec FactoMineR
	Exercices 1 à 3 : cf. syllabus


PARTIE 5 - Programmation avancée avec R (4h)
Section 1 : Programmation avancée avec R
	- Structures de contrôle : boucles, conditions, fonctions
	- Programmatoin fonctionnelle avec purrr
	- Création de packages R
	- Bonnes pratiques de programmation avec R

	Exercices 1 à 2 : cf. syllabus

































